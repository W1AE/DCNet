%% Connect-4
%% [1] Data Loading (We provide two different way, one way is based on libsvmread function, and the second way is to use the load function to load the dataset)
%
[label_vector, instance_matrix] = libsvmread('connect4');
data1=full(instance_matrix);
data=[label_vector data1];
data=mapminmax(data',0,1);
data=data';
rand_sequence=randperm(size(data,1));
temp_data=data;
data=temp_data(rand_sequence, :);
Training=data(1:50000,:);
nn=size(Training,2)-1;
numClasses=3;
Testing=data(50001:67557,:);
save_train=Training;
save_test=Testing;
save Connect4.mat save_train save_test;
%}

load Connect4.mat;

%% [2] DCNet
rate1=[10e-3 10e-3 10e-3 10e-4 10e-4 10e-4 10e-5 10e-5 10e-5 10e-6 10e-6 10e-6 10e-6 10e-6];

for ijk =1:3
    imageInputSize = [1 1 nn];  %126 is the dimension of the input data
    Size_a=[32 64 128];
    
    Size=Size_a(ijk);
    
    XTrain=save_train(:,2:end)';
    XTrain=reshape(XTrain,1,1,size(XTrain,1),size(XTrain,2));
    YTrain= categorical(save_train(:,1)*2);
    XTest=save_test(:,2:end)';
    XTest=reshape(XTest,1,1,size(XTest,1),size(XTest,2));
    YTest= categorical(save_test(:,1)*2);
    
    layers = [
        imageInputLayer(imageInputSize,'Normalization','none','Name','images')%New,43*43
        transposedConv2dLayer(2,512);%
        leakyReluLayer('Name','relu')
        transposedConv2dLayer(3,256);%
        leakyReluLayer('Name','relu')
        transposedConv2dLayer(5,128);
        leakyReluLayer('Name','relu')
        transposedConv2dLayer(9,64);
        leakyReluLayer('Name','relu')
        transposedConv2dLayer(9,3);
        leakyReluLayer('Name','relu')
        transposedConv2dLayer(9,1);
        leakyReluLayer('Name','relu')
        convolution2dLayer(2,3,'Padding','same')
        reluLayer('Name','relu')
        maxPooling2dLayer(2,'Stride',2)
        convolution2dLayer(2,128,'Padding','same')
        reluLayer('Name','relu')
        maxPooling2dLayer(2,'Stride',2)
        convolution2dLayer(2,256,'Padding','same')
        reluLayer('Name','relu')
        maxPooling2dLayer(2,'Stride',2)
        convolution2dLayer(2,512,'Padding','same')
        reluLayer('Name','relu')
        maxPooling2dLayer(2,'Stride',2)
        fullyConnectedLayer(numClasses,'Name','fc2')
        softmaxLayer('Name','softmax')
        classificationLayer('Name','classification')];
    
    for iii = 1:9
        rate=rate1(iii);
        options = trainingOptions('sgdm', ...
            'LearnRateSchedule', 'piecewise', ...
            'LearnRateDropFactor', 0.1, ...
            'LearnRateDropPeriod', 3, ...
            'MaxEpochs', 1, ...
            'InitialLearnRate', rate, ...
            'MiniBatchSize', Size);
        net = trainNetwork(XTrain,YTrain,layers,options);
        
        %acc_SNN=test_accuracy
        YPred = classify(net,XTest);
        acc_DECO(ijk,iii) = sum(YPred == YTest)./numel(YTest)
        layers = net.Layers;
    end
end




%% [3] TSNE to visualize the results
nnum=5000;
name='transposed-conv_6';
XTrain1t=save_train(1:nnum,2:end)';
XTrain1t=reshape(XTrain1t,1,1,size(XTrain1t,1),size(XTrain1t,2));
trainingFeatures = activations(net, XTrain1t, name,'MiniBatchSize',Size);
a1=size(trainingFeatures,1);%
a2=size(trainingFeatures,2);
a3=size(trainingFeatures,3);
a4=size(trainingFeatures,4);


X_train1=reshape(trainingFeatures,[a1*a2*a3,a4])';
T_train1=save_train(1:nnum,1);
TSNE(X_train1', T_train1', 2, 50);
