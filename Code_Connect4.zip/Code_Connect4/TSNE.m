function [] = TSNE(P,T,number_of_dimensions,number_of_PCA_components)

% P is the input attributes
% T refers to the labels

rng default % for reproducibility
Y = tsne(P','Algorithm','barneshut','NumPCAComponents',number_of_PCA_components,'NumDimensions',number_of_dimensions);

switch number_of_dimensions
    case 2
        figure
        gscatter(Y(:,1),Y(:,2),T)
    case 3
        figure
        scatter3(Y(:,1),Y(:,2),Y(:,3),15,T,'filled');
        view(-93,14)     
end
end