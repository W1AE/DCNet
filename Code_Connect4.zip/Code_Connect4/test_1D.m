s = load("HumanActivityTrain.mat");

dsXTrain = arrayDatastore(s.XTrain,'OutputType','same');
dsYTrain = arrayDatastore(s.YTrain,'OutputType','same');

dsTrain = combine(dsXTrain,dsYTrain);


numObservations = numel(s.XTrain);
classes = categories(s.YTrain{1});
numClasses = numel(classes);

A=1;